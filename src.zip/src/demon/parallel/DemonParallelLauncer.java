package demon.parallel;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import org.pcj.PCJ;
import org.pcj.Shared;
import org.pcj.StartPoint;
import org.pcj.Storage;

import labelPropagation.CommunityList;
import labelPropagation.GraphLoader;
import labelPropagation.NeighborList;

public class DemonParallelLauncer extends Storage implements StartPoint {
	@Shared
	ArrayList<NeighborList<Integer>>[] array;
	@Shared
	CommunityList<Integer> globalCommunities;

	@SuppressWarnings("rawtypes")
	@Shared
	ArrayList[] requestArray, responseArray, requests, responses, sendReceiveRequest, sendReceiveResponse;
	@Shared
	RequestPacket[] packetRequest;
	@Shared
	ResponsePacket[] packetResponse;

	public void main() throws IOException {

		/*
		 * double epsilon = 0; do { runExperiment(epsilon); epsilon = epsilon +
		 * 0.1; } while (epsilon <= 1.0);
		 */

		runExperiment(1);

	}

	private void runExperiment(double epsilon) throws IOException {
		// TODO Auto-generated method stub

		requestArray = new ArrayList[PCJ.threadCount()];
		responseArray = new ArrayList[PCJ.threadCount()];
		requests = new ArrayList[PCJ.threadCount()];
		responses = new ArrayList[PCJ.threadCount()];
		sendReceiveRequest = new ArrayList[PCJ.threadCount()];
		sendReceiveResponse = new ArrayList[PCJ.threadCount()];
		packetRequest = new RequestPacket[PCJ.threadCount()];
		packetResponse = new ResponsePacket[PCJ.threadCount()];
		GraphLoader graphLoader = new GraphLoader("com-amazon.ungraph.txt");
		int numberOfVertices = GraphLoader.numberOfElements;
		Indexer<Integer> indexer = new Indexer<Integer>();

		array = indexer.index(graphLoader.getNetwork());
		graphLoader = null;
		double startTime = System.nanoTime();

		DemonParallel<Integer> demon = new DemonParallel<Integer>(requestArray, responseArray, requests, responses,
				sendReceiveRequest, sendReceiveResponse, packetRequest, packetResponse);
		/*
		 * change merge factor to see its effect. 1 mean s merge communities iff
		 * bigger community fully contains smaller community
		 */
		PCJ.barrier();
		demon.execute(indexer.getLocalNetwork(), epsilon, 1, numberOfVertices);
		double estimatedTime = (System.nanoTime() - startTime) / 1000000000.;
		if (PCJ.myId() == 0)
			System.out.println("Total Time: " + estimatedTime + " seconds");
		globalCommunities = demon.getGlobalCommunities();

		// call performGlobalMerge() here

	}

	public static void main(String[] args) {

		PCJ.deploy(DemonParallelLauncer.class, DemonParallelLauncer.class, "nodes.txt");

	}
}
